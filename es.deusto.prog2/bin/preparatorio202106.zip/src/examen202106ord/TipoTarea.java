package examen202106ord;

public enum TipoTarea {
	ESTUDIO, DEPORTE, OCIO, HOGAR, EXAMEN, OTROS
}
